import { NotFoundComponent } from './not-found/not-found.component';
export const sharedComponents = [
  NotFoundComponent,
];
