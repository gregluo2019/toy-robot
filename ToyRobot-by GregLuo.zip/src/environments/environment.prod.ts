export const environment = {
  production: true,
  baseUrl: "https://toplearning.com.au",
  baseUrlWeb: "https://toplearning.com.au",
};
